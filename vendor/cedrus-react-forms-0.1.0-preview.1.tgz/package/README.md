# @cedrus/react-forms

The package shares numeric editing and accessible field bindings between React Hook Form consumers. The application supplies the input, layout, translated messages and domain schema.

Call `useNumericField({ control, name })` inside a component. Spread `labelProps` onto the label and `inputProps` onto the input. When `message` is present, render it inside an element with `messageProps`. The input keeps the text being edited until the resolver runs. A required blank stays empty. For an optional field pass `optional: true` and allow `undefined` in the schema.

Import `requiredNumericInput` from `@cedrus/react-forms/zod` to reject missing input before Zod coercion. For example, `requiredNumericInput(z.coerce.number().positive(), "Enter a price")` retains the application's positive-price rule.

From this directory run `npm ci`, `npm test` and `npm pack`. The tarball contains the compiled ESM and TypeScript declarations. Both pilot applications pin the same packed file and its npm lockfile integrity so a clean checkout can install it before registry publication.
