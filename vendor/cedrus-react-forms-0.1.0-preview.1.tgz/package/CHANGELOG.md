# Changelog

## 0.1.0-preview.1

First preview for the Compendium health fields and the Fronted product price field. Includes typed React Hook Form bindings and a Zod guard for required numeric values.
